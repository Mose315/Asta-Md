# Security Notice

## Supported Versions Node Versions to run this bot

Please Use Node Version Higher to Get The Best Performance.

| Version | Supported          |
| ------- | ------------------ |
| 14.x   | :x: |
| 16.x   | ❗                |
| 18.x   | :white_check_mark: |
| 20.x   | ✅                |

## Reporting a Vulnerability

